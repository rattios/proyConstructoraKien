<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><strong>Código de verificacion: </strong>{!!$codigo_verificacion!!}</p>
	<br>
	<p>Saludos cordiales, el equipo de Manappger.</p>
</body>
</html>