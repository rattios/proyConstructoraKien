<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><strong>Código de verificación: </strong>{!!$codigo_verificacion!!}</p>
	<br>
	<p>Saludos cordiales, el equipo de Constructora Kien.</p>
</body>
</html>