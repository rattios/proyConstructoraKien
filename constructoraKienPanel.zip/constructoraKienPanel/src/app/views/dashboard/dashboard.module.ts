import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts/ng2-charts';

import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { FormBuilder, FormArray, FormGroup, Validators  } from '@angular/forms';

import { FormsModule } from '@angular/forms';

import { ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';

import { AgmCoreModule } from '@agm/core';

@NgModule({
  imports: [
  	AgmCoreModule.forRoot({
        apiKey: 'AIzaSyA-jqEhc9PPkdmpvjqcNnppOFLj8brNIEQ'
      }),
  	CommonModule,
  	ReactiveFormsModule,
  	FormsModule,
    DashboardRoutingModule,
    ChartsModule
  ],
  declarations: [ DashboardComponent],
  
})
export class DashboardModule { }
