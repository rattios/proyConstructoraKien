import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { FormBuilder, FormArray, FormGroup, Validators  } from '@angular/forms';

@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent {

  public usuario;

	//public fb: FormBuilder
	//Objeto para manejar el formulario
  	myForm: FormGroup;
    formularioMovimiento : FormGroup;

  constructor(public fb: FormBuilder) {

    // Definimos el objeto usuario, vació inicialmente (necesario)
    this.usuario = {
        "nombre": "",
        "apellidos": "",
        "email": "",
        "password": ""
    };

  	this.myForm = this.fb.group({
      nombre: ['', [Validators.required]],
      company: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10)]],
      /*email: ['', [Validators.required, Validators.email]],
      age: ['', [Validators.required]],
      url: ['', [Validators.pattern(/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/)]],
      password: ['', [Validators.pattern(/^[a-z0-9_-]{6,18}$/)]],*/
    });
   }

  ngOnInit() {
  	//alert('hola '+localStorage.getItem('constructora_user_nombre'));
  	//alert('token '+localStorage.getItem('constructora_token'));

    this.formularioMovimiento = this.fb.group({
      tipo: ['',Validators.required],
      categoria: [],
      fecha: [],
      importe:['',Validators.required]
    });

  }

  onSubmit(){
    // Mostramos el objeto usuario
    console.log(this.usuario);
  }

  saveData(){
    alert(JSON.stringify(this.myForm.value));
  }

  guardarMovimiento() {       
    alert(JSON.stringify(this.formularioMovimiento.value));
  }

}
